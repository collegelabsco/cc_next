package com.devsquare.rescue;

/**
 * Created by IntelliJ IDEA.
 * User: administrator
 * Date: 19 Dec, 2009
 * Time: 12:57:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class ServerData {
    public static int STOP = 1;
    public static int NOP = 2;
    public static int INIT = 3;
    public static int BOARD = 4;
    int command;
    String msg;
    String gameid;
    int step;
    int bonus;
    int level;
    char[][] board = null;
    int col;
    int rows;
    int x,y;
    int ex,ey;
}
