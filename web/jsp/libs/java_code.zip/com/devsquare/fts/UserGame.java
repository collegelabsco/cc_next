package com.devsquare.fts;

//import java libraries as per needed

public class UserGame {
	
	public static void main(String[] args) {
		try{
			if (args.length == 0) {
	            System.out.println("Please pass the game id as an argument.");
	            return;
	        }
	        System.out.println("Starting with gameid: " + args[0]);
	        GameInterface game = new GameInterface(args[0], 1); //change this to 2 for level-2 and so on	       
			//write your code here
			//example
	        game.makeMove("move","down"); //moves player block down by one step
			//example
			game.makeMove("move","right"); //moves player block right by one step
	        	
		}
		catch(Exception e) {
			System.out.println("Unable to Solve Maze");
		}			

	}
	
}