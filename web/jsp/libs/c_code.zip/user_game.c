#include "game_interface.c"


int main(int argc, char *argv[])
{
	if(argc != 2) {
		printf("Please pass the gameid as argument\n");
		return FAILURE;
	}
	printf("starting with gameid: %s\n", argv[1]);
	int connection = connect_usergame();
	int i=0, j=0;
	if(connection==0) {	
		initialize(argv[1],1);  //where argv[1] is gameid and 1 stands for the game level
		
		//write your code here
		//example
		while(is_finished() == 0) {
			
			
			while(check_neighbour(player_pos, DOWN) == 0)
				make_move("move", "down");
			
			while(check_neighbour(player_pos, LEFT) == 0)
				make_move("move", "down");
			
		}
		
	}
	return SUCCESS;
}
	 